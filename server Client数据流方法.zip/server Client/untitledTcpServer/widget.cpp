#include "widget.h"
#include "ui_widget.h"
#include <QDataStream>
#include <QString>
#include <QtCore>
#include <algorithm>
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    server = new QTcpServer(this);//建立服务器对象基于当前界面
    //监听状态，监听所有可能连接的客户端
    //端口号一般设置1000以上，不要选择80开头
    if(server->listen(QHostAddress::Any,6667))
    {
        //提示监听失败-
        qDebug() << "监听失败";
    }
    //建立一个信号与槽函数的连接机制
    //如果有客户端连接，服务器就会产生newConnection
    //则获取客户端的套接字，之后用于通信
    connect(server,&QTcpServer::newConnection,this,&Widget::getSocket);

}

Widget::~Widget()
{
    delete ui;
}

void Widget::getSocket()
{
    //获取客户端连接后的套字节信息
    socket = server->nextPendingConnection();
    //如果有数据发送过来，套接字对象会产生一个准备读取信号，
    //则通过界面对象，执行槽函数接收数据
    connect(socket,&QTcpSocket::readyRead,this,&Widget::getMsg);
}

void Widget::getMsg()
{


     bufSize=0;
    //数据流方式
    //套接字对象与数据流对象关联
    QDataStream in(socket);//用于接收数据的对象
    in.setVersion(QDataStream::Qt_5_12);

    if(bufSize == 0)
    {
        if(socket->bytesAvailable()<2)
        {
            qDebug() << "数据大小值没有接收到";
            return;//终止当前函数
        }
       in >> bufSize;//bufSize只有2个字节大小 放入2值（2个字节）
       if(socket->bytesAvailable()<bufSize)
       {
           //判断真实数据与大小值进行比较
           qDebug() << "数据真实值没有接收到";
           return;
       }
       in >> msg;//数据流中获取数据，存放到msg中
       qDebug() << msg;
       ui->lineEdit->setText(msg);//显示
       //
        Widget::Writedata();
    }
}

//发送翻转字符串的函数
void Widget::Writedata()
{

   QString fanzhuan__msg = msg;
   //qDebug() <<"2222" << weifanzhuan__msg;
   //以下操作为反转字符串fanzhuan__msg使其成为反转结果后的字符串reversedString
   QString originalString = fanzhuan__msg;
   QString reversedString = originalString;
   std::reverse(reversedString.begin(), reversedString.end());

   qDebug() << "原始字符串：" << originalString;
   qDebug() << "反转后的字符串：" << reversedString;
    //将反转后的字符串放入到dataToSend中发送  dataToSend是一个暂时存储数据的变量

    QString dataToSend = reversedString; // 您要发送的数据
       // 将 QString 转换为 QByteArray
       //QByteArray dataByteArray = dataToSend.toUtf8(); // 使用 UTF-8 编码，可以根据需要更改编码方式
    //设置数据缓冲区（缓存区：数据临时存放位置，其中数据还要不断进行更新）
    QByteArray buf;//Qt字节数组，临时存储要发送的数据
    //数据流方式
    //参数1：设置缓存区位置；参数2：设置数据流方向
    QDataStream out(&buf,QIODevice::WriteOnly);//数据对象
    //设置数据流版本
    out.setVersion(QDataStream::Qt_5_12);
    //数据格式：前n位表示数据的大小值，后面若干位表示数据的真实信息
    // << 左移运算符
    out << (quint16)0;//用两位表示数据的大小
    out << dataToSend;
    out.device()->seek(0);//跳转到起始位置
    out << (quint16)(buf.size() - sizeof (quint16));
       // 使用套接字发送数据

       socket->write(buf);

}
