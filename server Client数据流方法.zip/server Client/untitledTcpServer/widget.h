#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void getSocket();
    void getMsg();
    void Writedata();
private:
    Ui::Widget *ui;
    QTcpServer *server;
    QTcpSocket *socket;
    quint16 bufSize;//存储数据大小值
    QString msg;
    //
    QString weifanzhuan__msg;
};

#endif // WIDGET_H
