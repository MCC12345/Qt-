#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpSocket>
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    //
    void getMsg();
private:
    Ui::Widget *ui;
    QTcpSocket *clientSocket;
    //

    quint16 bufSize;//存储数据大小值
    QString msg;


};

#endif // WIDGET_H
