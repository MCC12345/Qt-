#include "widget.h"
#include "ui_widget.h"
#include <QDataStream>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    clientSocket = new QTcpSocket(this);

    connect(clientSocket, &QTcpSocket::readyRead, this, &Widget::getMsg); // 连接接收数据的槽函数
}

Widget::~Widget()
{
    delete ui;
}

//连接服务器
void Widget::on_pushButton_clicked()
{
    if(ui->pushButton->text() == "链接服务器")
    {
        QString ip = ui->lineEdit->text();
        QString port = ui->lineEdit_2->text();
        //客户端连接服务器
        clientSocket->connectToHost(ip,port.toInt());
        //设置按钮改变
        ui->pushButton->setText("断开服务器");
    }
    else
    {
       clientSocket->abort();//断开服务器
       ui->pushButton->setText("链接服务器");
    }

}

//数据发送
void Widget::on_pushButton_2_clicked()
{

    //设置数据缓冲区（缓存区：数据临时存放位置，其中数据还要不断进行更新）
    QByteArray buf;//Qt字节数组，临时存储要发送的数据
    //数据流方式
    //参数1：设置缓存区位置；参数2：设置数据流方向
    QDataStream out(&buf,QIODevice::WriteOnly);//数据对象
    //设置数据流版本
    out.setVersion(QDataStream::Qt_5_12);
    //数据格式：前n位表示数据的大小值，后面若干位表示数据的真实信息
    // << 左移运算符
    out << (quint16)0;//用两位表示数据的大小
    out << ui->lineEdit_3->text();
    out.device()->seek(0);//跳转到起始位置
    out << (quint16)(buf.size() - sizeof (quint16));

//    int num = clientSocket->write(buf);
//    qDebug() << num;
    clientSocket->write(buf);
    //

}

//接收数据
void Widget::getMsg()
{
//    QByteArray data = clientSocket->readAll(); // 读取所有数据

//    QString msg = QString::fromUtf8(data); // 将字节数组转换为字符串

//    qDebug() << "Received message: " << msg;
    bufSize=0;
   //数据流方式
   //套接字对象与数据流对象关联
   QDataStream in(clientSocket);//用于接收数据的对象
   in.setVersion(QDataStream::Qt_5_12);

   if(bufSize == 0)
   {
       if(clientSocket->bytesAvailable()<2)
       {
           qDebug() << "数据大小值没有接收到";
           return;//终止当前函数
       }
      in >> bufSize;//bufSize只有2个字节大小 放入2值（2个字节）
      if(clientSocket->bytesAvailable()<bufSize)
      {
          //判断真实数据与大小值进行比较
          qDebug() << "数据真实值没有接收到";
          return;
      }
      in >> msg;//数据流中获取数据，存放到msg中
      qDebug() << msg;
    ui->lineEdit_4->setText(msg); // 显示接收到的消息
   }
}
